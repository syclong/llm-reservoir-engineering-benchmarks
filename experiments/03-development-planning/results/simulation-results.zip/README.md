# Experiment 03 recorded simulations

This archive contains the five language-model plans and all 25 plans from the five-generation particle swarm comparison. All 30 JutulDarcy simulations reached day 3650. Each run starts from the same initial reservoir state.

## Files

- `comparison.json` contains the primary budgets, the winning plan in each arm, and the difference in field cumulative surface oil production.
- `llm_rounds.csv`, `particles.csv`, and `generations.csv` contain the five language-model scores and plans, the 25 individual particle scores and plans, and the five generation summaries.
- `llm/r01/` through `llm/r05/` contain the five language-model evaluations. Each directory includes the proposal as returned in `response.json.txt` and its English-edition prompt in `prompt.txt`. `llm/calls.json` records the message and tool counts for the five completed responses.
- `pso25/r01/` through `pso25/r25/` contain the five particles in each generation, in evaluation order. Each directory includes its submitted `plan.json`. The frozen plans for each generation are in `pso25/generations/`.
- Both arms have per-evaluation `MODEL.DATA`, `record.json`, `verification.json`, `history.csv`, `feedback.txt`, `launched.txt`, and a `jutul/` directory. Study registrations and the recorded arm-level numerical checks are in `study.json` and `audit.json` within each arm.

## Simulation outputs

`history.csv` covers every accepted solver substep. TIME is in days, production and injection rates are in standard cubic meters per day, cumulative surface volumes are in standard cubic meters, and absolute pressures are in bar. The final FOPT is the score for that plan.

`jutul/steps.csv` contains accepted substep times and durations in seconds, signed surface rates in m³/s, pressures in Pa, and well open/closed indicators. `jutul/initial.csv` and `jutul/final.csv` each contain 3,000 active cells. The columns are one-based cell index, pore volume in m³, absolute pressure in Pa, oil saturation, and water saturation. The grid is 60 × 50 × 1, with I varying fastest. `jutul/complete.toml` is the simulator completion receipt. `verification.json` includes independent oil-volume checks, shut-in dates, and hashes of the raw solver files.

## Text editions

The study used Chinese prompts. The public prompts and feedback use English wording with the recorded plans, scores, production histories, and grid values. Two DATA comment lines are translated. The well proposals, numerical CSVs, simulator receipts, and per-evaluation records retain their recorded bytes. The receipt and record hashes refer to the original files used in the simulations. `text_editions.csv` maps the recorded hashes to the English-edition hashes for the decks, feedback, and prompts.

Run `python experiments/03-development-planning/reproduce.py verify` from the benchmark repository to replay the scores from this archive.

